package practice02;

public class BankAccount {
  public BankCustomer forCust;
  public double balance;
  
  public BankAccount (BankCustomer forCust, double balance) {
    this.forCust = forCust;
    this.balance = balance;
  }
}