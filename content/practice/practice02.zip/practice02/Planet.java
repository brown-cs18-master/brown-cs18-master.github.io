package practice02;

public class Planet {
  public String name;
  public double distToSun;
  public double relGravity;
  
  public Planet (String name, double distToSun, double relGravity) {
    this.name = name;
    this.distToSun = distToSun;
    this.relGravity = relGravity;
  }  
}