package practice02;

public class BankCustomer {
  public String firstName;
  public String lastName;

  public BankCustomer (String firstName, String lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }
}