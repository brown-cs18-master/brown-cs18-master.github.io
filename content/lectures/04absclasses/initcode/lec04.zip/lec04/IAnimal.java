package lec04;

// a new type name for animals
public interface IAnimal {}
