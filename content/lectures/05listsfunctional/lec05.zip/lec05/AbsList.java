package lec05;

public abstract class AbsList implements IList {
  /**
   * Construct a list with given element in first position
   * @param elt -- the item to add to the list
   */
  public IList addFirst(int elt) {
    return new NodeList(elt, this);
  }
}
