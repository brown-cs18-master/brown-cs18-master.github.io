package lec07;
import java.util.LinkedList;

public class JListExample {
	
	JListExample(){}
	
	public static void main(String[] args) {
		LinkedList<Integer> L = new LinkedList<Integer>();
		L.addFirst(3);
		L.addFirst(5);
		
		// compute sum of items in L
		Integer total = 0;  // a variable to hold the running sum
		for (Integer num : L) {
			total = total + num;
		}
		System.out.println(total);
	}
}
