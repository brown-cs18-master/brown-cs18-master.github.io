package lec03;

public class Boa {
    public String name;
    public Integer length;
    public String eats;

    public Boa(String name, Integer length, String eats) {
        this.name = name;
        this.length = length;
        this.eats = eats;
    }
}

