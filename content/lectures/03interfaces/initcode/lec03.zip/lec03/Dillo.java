package lec03;

public class Dillo {
    public int length;
    public boolean isDead;

    public Dillo(int len, boolean isD) {
        this.length = len;
        this.isDead = isD;
    }

    // determine whether dillo is long and dead
    public boolean canShelter() {
        return this.isDead && (this.length > 60);
    }
}
