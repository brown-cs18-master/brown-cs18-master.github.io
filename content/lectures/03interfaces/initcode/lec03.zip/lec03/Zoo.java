package lec03;

public class Zoo {
    Dillo animal1;
    Dillo animal2;

    // The Zoo Constructor
    public Zoo(Dillo ani1, Dillo ani2) {
        this.animal1 = ani1;
        this.animal2 = ani2;
    }
}
