package lec14;
import java.util.LinkedList;
import java.util.Scanner;
import org.apache.commons.csv.CSVParser;

public class BankingService {
    private LinkedList<Account> accounts = new LinkedList<Account>();
    private LinkedList<Customer> customers = new LinkedList<Customer>();

    public BankingService(){}

    public void addAccount(Account newA) {
        this.accounts.addFirst(newA);
    }

    // this method is new -- it creates a helper from the
    // for loops that were in getBalance and withdraw
    private Account findAccount(int forAcctNum) {
        for (Account acct:accounts) {
            if (acct.numMatches(forAcctNum))
                return acct;
        }
        return null;
    }

    public double getBalance(int forAcctNum) {
        return findAccount(forAcctNum).getBalance();
    }

    public double withdraw(int forAcctNum, double amt) {
        return findAccount(forAcctNum).withdraw(amt);
    }

    // this method is new: it provides keyboard input for logging in
    public void loginScreen() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Welcome to the Bank.  Please log in.");
        System.out.print("Enter your username: ");
        String username = keyboard.next();
        System.out.print("Enter your password: ");
        String password = keyboard.next();
        this.login(username, password);
        System.out.println("Thanks for logging in!");
    }

    private Customer findCustomer(String custname) {
        for (Customer cust:customers) {
            if (cust.nameMatches(custname)) {
                return cust;
            }
        }
        return null;
    }

    public String login(String custname, String withPwd) {
        Customer cust = findCustomer(custname);
        if (cust.checkPwd(withPwd)) {
            return "Welcome";
        } else {
            return "Try Again";
        }
        return "Oops -- don't know this customer";
    }

}
