package lec14mvc;
import java.util.LinkedList;

public class BankingService {
    private AccountList accounts = new AccountList();
    private LinkedList<Customer> customers = new LinkedList<Customer>();

    public BankingService(){}

    public void addAccount(Account newA) {
        accounts.addAccount(newA);
    }

    public double getBalance(int forAcctNum) {
        return accounts.findAccount(forAcctNum).getBalance();
    }

    public double withdraw(int forAcctNum, double amt) {
        return accounts.findAccount(forAcctNum).withdraw(amt);
    }

    public String login(String custname, String withPwd) {
        for (Customer cust:customers) {
            if (cust.nameMatches(custname)) {
                if (cust.checkPwd(withPwd)) {
                    return "Welcome";
                } else {
                    return "Try Again";
                }
            }
        }
        return "Oops -- don't know this customer";
    }
}
