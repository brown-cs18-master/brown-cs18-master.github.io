package lec14mvc;

public class Main {
    public static void main(String[] args) {
        BankingService controller = new BankingService();
        BankingConsole view = new BankingConsole(controller);
        Customer kCust = new Customer("kathi", "cs18");
        Account kAcct = new Account(100465, kCust, 150);
        controller.addAccount(kAcct);
        view.loginScreen();
        kAcct.printBalance();
        controller.withdraw(100465, 30);
        kAcct.printBalance();
    }
}
