package lec12;
import java.util.Iterator;

public interface IList<T> extends Iterable<T> {
	public int size();
	public void addFirst(T elt);
	public void addLast(T elt);
	public boolean contains(T elt);
	public Iterator<T> iterator();
}
