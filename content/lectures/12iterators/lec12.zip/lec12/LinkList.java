package lec12;
import java.util.Iterator;

public class LinkList<T> implements IList<T> {
	Node start;
	Node end;
	int eltCount;
	
	public LinkList() {
		this.start = null; 
		this.end = null; 
		this.eltCount = 0;
	}
	
	// ----------------------------------------------------------

	// The inner node class -- prevents use from outside LinkList
	class Node {
		T item;
		Node next;
		
		Node(T item, Node next) {
			this.item = item;
			this.next = next;
		}
	}
	
	// ----------------------------------------------------------

	// The inner iterator class -- enables for loops over LinkLists
	class LinkListIterator implements Iterator<T> {
		Node current;
		
		public LinkListIterator(LinkList<T> theList) {
			this.current = theList.getStart();
		}
		
		@Override
		public boolean hasNext() {
			return (this.current != null);
		}
		
		@Override
		public T next() {
			T item = this.current.item;
			this.current = this.current.next;
			return item;
		}
	}
	
	// ------- the methods ----------------------------------------
	
	public Iterator<T> iterator() {
		return new LinkListIterator(this);
	}
	
	/*
	 * @return the starting node in the list, used by the iterator
	 */
	public Node getStart() {
		return this.start;
	}
	
	/*
	 * indicate whether the list is empty
	 */
	 boolean isEmpty() {
		 return ((this.start == null) && (this.end == null));
	 }
	
	 /* 
	  * @return the number of elements in the list
	  */
	public int size() { 
		return this.eltCount; 
	}
	
	/*
	 * adds an item to the front of the list
	 * @param elt - the element to add
	 */
	public void addFirst(T elt) {
		Node newN = new Node(elt, this.start);
		this.start = newN;
		if (this.end == null) {
			this.end = newN;
		}
	}
	
	/*
	 * adds an item to the end of the list
	 * @param elt - the element to add
	 */
	public void addLast(T elt) {
		if (this.isEmpty()) {
			this.addFirst(elt);
		} else {
			Node newNode = new Node(elt, null);
			this.end.next = newNode;
			this.end = newNode;
		}
	}
	
	/*
	 * determines whether an element is in the list
	 * @param elt - the element to search for in the list
	 * @return whether the element is in the list
	 */
	public boolean contains(T elt) {
		for(T listElt : this) {
			if (listElt.equals(elt)) {
				return true;
			}
		}
		return false;
	}	
}

