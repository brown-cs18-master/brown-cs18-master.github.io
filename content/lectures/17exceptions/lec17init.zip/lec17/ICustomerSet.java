package lec17;

public interface ICustomerSet {
    public void addCustomer(Customer newC);
    public Customer findCustomer(String custname);
}
