package lec17;

import java.util.LinkedList;

public class CustomerList implements ICustomerSet {
    private LinkedList<Customer> customers = new LinkedList<Customer>();

    public void addCustomer(Customer newC) {
        this.customers.addFirst(newC);
    }

    public Customer findCustomer(String custname) {
        for (Customer cust : customers) {
            if (cust.nameMatches(custname)) {
                return cust;
            }
        }
        return null;
    }
}
