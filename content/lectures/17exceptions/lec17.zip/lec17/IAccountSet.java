package lec17;

public interface IAccountSet {
    public void addAccount(Account newA);
    public Account findAccount(int forAcctNum);
}
