package lec17;

// this exception doesn't carry additional information
//  so the class has no fields or methods.
public class LoginFailedException extends Exception {
    public String custname;
    public LoginFailedException(String name) {
        this.custname = name;
    }
}
