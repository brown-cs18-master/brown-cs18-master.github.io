package lec17;

public class CustomerNotFoundException extends Exception {
    // this class represents the details of a customer not found error
    // typically have fields for key info about the error
    public String custname;

    public CustomerNotFoundException(String name) {
        this.custname = name;
    }
}
