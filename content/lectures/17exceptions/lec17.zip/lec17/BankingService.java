package lec17;
import java.util.LinkedList;

public class BankingService {
    private IAccountSet accounts;
    private ICustomerSet customers;
    private LinkedList<Customer> loggedIn = new LinkedList<Customer>();

    public BankingService(IAccountSet A, ICustomerSet C){
        this.accounts = A;
        this.customers = C;
    }
    public void addAccount(Account newA) {
        accounts.addAccount(newA);
    }
    public void addCustomer(Customer newC) {
        customers.addCustomer(newC);
    }
    public double getBalance(int forAcctNum) {
        Account a = accounts.findAccount(forAcctNum);
        if (this.loggedIn.contains(a.owner))
            return a.getBalance();
        return 0;
    }
    public double withdraw(int forAcctNum, double amt) {
        return accounts.findAccount(forAcctNum).withdraw(amt);
    }

    public String login(String custname, String withPwd)
            throws CustomerNotFoundException, LoginFailedException {
        Customer cust = customers.findCustomer(custname);
        if (!cust.checkPwd(withPwd))
            throw new LoginFailedException(custname);
        this.loggedIn.addFirst(cust);
    }
}
