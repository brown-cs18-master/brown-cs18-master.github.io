package lec08;

public interface IList {
  /**
   * determine whether a list is empty
   */
  public boolean isEmpty();

  /**
   * Construct a list with given element in first position
   * @param elt -- the item to add to the list
   */
  public IList addFirst(int elt);

  /**
   * Remove first occurrence of item in a list
   * @param elt -- the item to remove
   */
  public IList remEltOnce(int elt);

  /**
   * Produce the number of elements in the list
   */

  public int length();

  /**
   * Get the first element of the list
   */
  public int head();
}
