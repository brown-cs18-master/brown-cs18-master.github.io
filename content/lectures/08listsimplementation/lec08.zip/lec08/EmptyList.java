package lec08;

public class EmptyList extends AbsList {
  
  // constructor
  public EmptyList() {
    super();
  }

  public IListInternal addLast(int newelt) {
    return new NodeList(newelt, this);
  }

  /**
   * reports that a NodeList is not empty 
   */
  public boolean isEmpty() {
    return true;
  }
  
  /**
   * Remove first occurrence of item in a list
   * @param remelt -- the item to remove
   */
  public IListInternal remEltOnce(int remelt) {
    return this;
  }

  /**
   * Produce the number of elements in the list
   */
  public int length() {
    return 0;
  }

  /**
   * Get the first element of the list
   */
  public int head() {
    throw new RuntimeException("Attempt to take head of empty list");
  }

  @Override
  public String toString() {
    return "";
  }
}
