package lec09;

public abstract class AbsList implements IListInternal {
  /**
   * Construct a list with given element in first position
   * @param elt -- the item to add to the list
   */
  public IListInternal addFirst(int elt) {
    return new NodeList(elt, this);
  }
}
