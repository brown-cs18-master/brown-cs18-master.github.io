package lec09;

public class Course {
  String dept;
  int number;
  String room;
  
  public Course(String dept, int num, String rm) {
    this.dept = dept;
    this.number = num;
    this.room = rm;
  }
  
  /**
   * produce same course but in a different room
   * @param newRm -- the new room for the course
   */
  public Course newRoom(String newRm) {
    return new Course(this.dept, this.number, newRm);
  }
  
  /**
   * produce same course but in a different room
   * @param newRm -- the new room for the course
   */
  public Course newRoom2(String newRm) {
    this.room = newRm;  // the = sign changes the field value
    return this;
  }

  public boolean equalsIdea(Course other) {
      return (this.dept.equals(other.dept) &&
              this.number == other.number);
  }

  @Override
  public boolean equals(Object other) {
    if (other instanceof Course) {
      Course c = (Course)other; // view (cast) object as a Course
      return (this.dept.equals(c.dept) && 
          this.number == c.number);
    } else {
      return false; // other isn't even a Course object
    }
  }
}
