package lec09;

public class ListTest {
    public ListTest() {}

    public static void main(String[] args) {
        IList list1 = new LinkList();
        list1 = list1.addFirst(3).addFirst(6).addFirst(3).addFirst(1);

        // no tests cases this time, just exploring lists with println
        System.out.println(list1.toString());
        list1 = list1.remEltOnce(3);
        System.out.println(list1.toString());
        list1 = list1.addFirst(5).remEltOnce(9);
        System.out.println(list1.toString());

        IList list2 = new LinkList().addFirst(2);
        System.out.println("list2 after remove: " + list2.remEltOnce(2).toString());
        System.out.println(list2);
    }
}