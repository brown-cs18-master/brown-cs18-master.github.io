package lec09;

public class ListTest {
    public ListTest() {}

    public static void main(String[] args) {
        // no tests cases this time, just exploring lists with println
        //   (so you know how to do this -- it can be useful in practice,
        //    but it lacks the automatic checking that your tests gave
        //    the right answer that checkExpect would do)

        // isEmpty
        IList list1 = new LinkList();
        System.out.println(list1.isEmpty());

        // testing add and remove
        list1 = list1.addFirst(3).addFirst(6).addFirst(3).addFirst(1);
        System.out.println(list1.isEmpty());
        System.out.println(list1.toString());
        list1 = list1.remEltOnce(3);
        System.out.println(list1.toString());
        list1 = list1.addFirst(5).remEltOnce(9);
        System.out.println(list1.toString());

        // testing remove with one-element lists
        IList list2 = new LinkList().addFirst(2);
        System.out.println("list2 after remove: " + list2.remEltOnce(2).toString());
        System.out.println(list2);

        // testing addLast
        LinkList list3 = new LinkList().addLast(6);
        list3.addLast(8);
        System.out.println(list3);

        // testing length
        // -- by here, this is getting painful to track, and checkExpect would be better
        LinkList list4 = new LinkList();
        list4 = list4.addFirst(3).addFirst(6).addFirst(3).addFirst(1);
        System.out.println(list4.toString());
        System.out.println(list4.length());
        list4.addFirst(7);
        System.out.println(list4.toString());
        System.out.println(list4.length());
        list4.addLast(8);
        System.out.println(list4.toString());
        System.out.println(list4.length());
        list4.remEltOnce(3);
        System.out.println(list4.toString());
        System.out.println(list4.length());
    }
}