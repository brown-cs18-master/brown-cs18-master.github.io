package lec09;

public class NodeList extends AbsList {
  int first;
  IListInternal rest;

  // constructor
  public NodeList(int fst, IListInternal rst) {
    super();
    this.first = fst;
    this.rest = rst;
  }
  
  /**
   * reports that a NodeList is not empty 
   */
  public boolean isEmpty() {
    return true;
  }

  public IListInternal addLast(int newelt) {
    this.rest = this.rest.addLast(newelt);
    return this;
  }
  
  /**
   * Remove first occurrence of item in a list
   * @param remelt -- the item to remove
   */
  public IListInternal remEltOnce(int remelt) {
    if (remelt == this.first) {
      return this.rest;
    } else {
      return new NodeList(this.first, this.rest.remEltOnce(remelt));
    }
  }

  /**
   * Produce the number of elements in the list
   */
  public int length() {
    return 1 + this.rest.length();
  }

  /**
   * Get the first element of the list
   */
  public int head() {
    return this.first;
  }

  @Override
  public String toString() {
    return this.first + ", " + this.rest.toString();
  }
}
