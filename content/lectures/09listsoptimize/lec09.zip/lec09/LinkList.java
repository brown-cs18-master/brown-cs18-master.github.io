package lec09;

public class LinkList implements IList {
    IListInternal start = new EmptyList();  // the actual list underneath
    IListInternal end = this.start; // the last NodeList in the list, or EmptyList if no nodes yet
    int eltCount = 0;

    LinkList(){}

    public boolean isEmpty() { return this.start.isEmpty(); }

    public LinkList addFirst(int newelt) {
        this.start = new NodeList(newelt, this.start);
        if (this.end.isEmpty())
            this.end = this.start;
        this.eltCount = this.eltCount + 1;
        return this;
    }

    // add the newelt to the end of the list
    // would like to do this in constant time as well
    public LinkList addLast(int newelt) {
        if (this.isEmpty()) { // end and start both refer to EmptyList
            this.end = new NodeList(newelt, this.end);
            this.start = this.end;
        } else { // end must already refer to a NodeList, which must now reference the new NodeList
            NodeList newN = new NodeList(newelt, ((NodeList)this.end).rest);
            ((NodeList)this.end).rest = newN;
            this.end = newN;
        }
        this.eltCount = this.eltCount + 1;
        return this;
    }

    /**
     * Remove first occurrence of item in a list
     * @param elt -- the item to remove
     */
    public IList remEltOnce(int elt) {
        this.start = this.start.remEltOnce(elt);
        if (this.isEmpty()) // could have broken relationship between end and start
            this.end = this.start;
        this.eltCount = this.start.length(); // calibrate the length
        return this;
    }

    /**
     * Produce the number of elements in the list
     */
    public int length() { return this.start.length(); }

    /**
     * Get the first element of the list
     */
    public int head() {return this.start.head(); }

    @Override
    public String toString() {
        return "[" + this.start.toString() + "]";
    }
}