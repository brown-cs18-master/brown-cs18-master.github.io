package lec09;

public interface IList {
  /**
   * determine whether a list is empty
   */
  public boolean isEmpty();

  /**
   * Produce a list with given element first followed by existing elements
   * @param elt -- the item to add to the list
   */
  public IList addFirst(int elt);

  /**
   * Produce a list with given element last preceded by existing elements
   * @param elt -- the item to add to the list
   */
  public IList addLast(int elt);

  /**
   * Remove first occurrence of item in a list
   * @param elt -- the item to remove
   */
  public IList remEltOnce(int elt);

  /**
   * Produce the number of elements in the list
   */

  public int length();

  /**
   * Get the first element of the list
   */
  public int head();
}
