package lec11;

public class ArrayBasedList {
    int maxSize;
    String[] contents;
    int start = 0; // the first occupied space, when list nonempty
    int end = 0;   // the next open space at the end of the array
    int eltCount = 0;

    ArrayBasedList(int capacity) {
        this.maxSize = capacity;
        this.contents = new String[maxSize];
    }

    public int length() {return eltCount; }

    // return the data value at the given index (count starts from 0)
    String get(int position) {
        if ((position >= 0) && (position < maxSize))
            return contents[(position + start) % maxSize];
        else
            throw new RuntimeException("position " + position + "out of bounds");
    }

    // resize when only adding to end of the list
    void resizeLastOnly() {
        int newMaxSize = maxSize * 2;
        String[] newContents = new String[newMaxSize];
        for (int index = 0; index < maxSize; index ++) {
            newContents[index] = contents[index];
        }
        maxSize = newMaxSize;
        contents = newContents;
    }

    // resize when can also add to the front
    void resize() {
        int newMaxSize = maxSize * 2;
        String[] newContents = new String[newMaxSize];
        for (int index = start; index < maxSize; index ++) {
            newContents[index - start] = contents[index];
        }
        for (int index = 0; index < start; index ++) {
            newContents[index + (maxSize - start)] = contents[index];
        }
        start = 0;
        end = maxSize;
        maxSize = newMaxSize;
        contents = newContents;
    }

    ArrayBasedList addFirst(String newelt) {
        if (this.eltCount == maxSize)
            this.resize();
        if (eltCount == 0) { // move end, but not start
            contents[start] = newelt;
            end = (end + 1) % maxSize;
        } else {  // move start, but not end
            start = ((start + maxSize - 1) % maxSize);
            contents[start] = newelt;
        }
        eltCount = eltCount + 1;
        return this;
    }

    ArrayBasedList addLast(String newelt) {
        if (eltCount == maxSize)
            this.resize();
        contents[end] = newelt;
        end = (end + 1) % maxSize;
        eltCount = eltCount + 1;
        return this;
    }

    public static void main(String[] args) {
        ArrayBasedList ourTAs = new ArrayBasedList(4);
        ourTAs.addLast("Carrie");
        ourTAs.addLast("Evan");
        Dillo iMissDillos = new Dillo(6, true);
        ourTAs.addLast("Nastassia");
        ourTAs.addLast("Put");
        ourTAs.addLast("Joe");
        ourTAs.addFirst("Annie");
        ourTAs.addFirst("Harshini");
        ourTAs.addLast("Alex");
        ourTAs.addLast("Peter");
    }
}
