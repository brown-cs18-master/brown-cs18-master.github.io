package lec11;

public class Dillo {
    int length;
    boolean isDead;
    Dillo(int len, boolean isD) {
        this.length = len;
        this.isDead = isD;
    }
}