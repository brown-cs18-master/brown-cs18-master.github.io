package lec11;

public class ArrayBasedList {
    int maxSize;
    String[] contents = null;
    int end = 0; //  the next open space in the array

    ArrayBasedList(int capacity) {
        this.maxSize = capacity;
        this.contents = new String[maxSize];
    }

    // return the data value at the given index (count starts from 0)
    String get(int index) {
        if ((index >= 0) && (index < maxSize))
            return contents[index];
        else
            throw new RuntimeException("index " + index + "out of bounds");
    }

    // add given item to the end of the array/list
    ArrayBasedList addLast(String newelt) {
        contents[this.end] = newelt;
        this.end = this.end + 1;
        return this;
    }

    public static void main(String[] args) {
        ArrayBasedList ourTAs = new ArrayBasedList(4);
        ourTAs.addLast("Carrie");
        ourTAs.addLast("Evan");
        Dillo iMissDillos = new Dillo(6, true);
        ourTAs.addLast("Nastassia");
        ourTAs.addLast("Put");
        ourTAs.addLast("Joe");
    }
}
